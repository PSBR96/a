App module notes:
- Open the project in Android Studio.
- The MainActivity is a Compose placeholder. Replace with your real UI.
- To build on GitHub Actions, the workflow triggers on push to main.
- You might need to accept licenses or set ANDROID_SDK_ROOT in CI for full emulator-based tests.
